# Edge Reconnection Implementation Guide

## Overview
The Edge Reconnection feature allows users to dynamically change which nodes are connected by dragging edge endpoints to new nodes. This guide provides complete implementation instructions for integrating this feature into your application.

## Table of Contents
1. [Feature Capabilities](#feature-capabilities)
2. [Implementation Steps](#implementation-steps)
3. [Code Examples](#code-examples)
4. [Visual Feedback System](#visual-feedback-system)
5. [Event Handling](#event-handling)
6. [Customization Options](#customization-options)
7. [Troubleshooting](#troubleshooting)

## Feature Capabilities

### What Users Can Do:
- **Select any edge** to reveal reconnection handles
- **Drag source or target handle** to disconnect that endpoint
- **Connect to different nodes** by dropping handle on target node
- **Cancel reconnection** by releasing in empty space
- **Visual validation** prevents duplicate connections

### Built-in Behaviors:
- Automatic edge validation (no duplicate edges)
- Smart connection point calculation
- Visual feedback during drag operations
- Coordinate transformation for panned/zoomed canvas
- Event prevention to avoid conflicts with canvas panning

## Implementation Steps

### Step 1: Import Required Components

```tsx
import { 
  KiteFrameCanvas, 
  EdgeHandles, 
  Node, 
  Edge,
  useKiteFrameStore 
} from '@kiteline/kiteframe';
```

### Step 2: Set Up State Management

```tsx
function WorkflowEditor() {
  const [nodes, setNodes] = useState<Node[]>([
    { 
      id: '1', 
      type: 'default', 
      position: { x: 100, y: 100 }, 
      data: { label: 'Start Node' } 
    },
    { 
      id: '2', 
      type: 'default', 
      position: { x: 300, y: 100 }, 
      data: { label: 'Process Node' } 
    },
    { 
      id: '3', 
      type: 'default', 
      position: { x: 500, y: 100 }, 
      data: { label: 'End Node' } 
    }
  ]);

  const [edges, setEdges] = useState<Edge[]>([
    { 
      id: 'edge-1', 
      source: '1', 
      target: '2',
      type: 'default'
    },
    { 
      id: 'edge-2', 
      source: '2', 
      target: '3',
      type: 'default'
    }
  ]);

  const [selectedEdge, setSelectedEdge] = useState<Edge | null>(null);
}
```

### Step 3: Implement Edge Selection Handler

```tsx
const handleEdgeClick = (edge: Edge) => {
  console.log('Edge selected:', edge.id);
  setSelectedEdge(edge);
};

const handleCanvasClick = () => {
  // Deselect edge when clicking canvas
  setSelectedEdge(null);
};
```

### Step 4: Implement Edge Reconnection Handler

```tsx
const handleEdgeReconnect = (
  edgeId: string, 
  newSource: string | undefined, 
  newTarget: string | undefined
) => {
  setEdges(prevEdges => {
    return prevEdges.map(edge => {
      if (edge.id === edgeId) {
        console.log(`Reconnecting edge ${edgeId}:`, {
          oldSource: edge.source,
          oldTarget: edge.target,
          newSource: newSource || edge.source,
          newTarget: newTarget || edge.target
        });
        
        return {
          ...edge,
          source: newSource || edge.source,
          target: newTarget || edge.target
        };
      }
      return edge;
    });
  });

  // Optional: Log the reconnection for debugging
  console.log('Edge reconnected successfully');
};
```

### Step 5: Integrate with KiteFrameCanvas

```tsx
return (
  <div style={{ width: '100%', height: '100vh' }}>
    <KiteFrameCanvas
      nodes={nodes}
      edges={edges}
      onNodesChange={setNodes}
      onEdgesChange={setEdges}
      onEdgeClick={handleEdgeClick}
      onClick={handleCanvasClick}
      selectedEdge={selectedEdge}
      onEdgeReconnect={handleEdgeReconnect}
    />
  </div>
);
```

## Code Examples

### Complete Minimal Implementation

```tsx
import React, { useState } from 'react';
import { KiteFrameCanvas, Node, Edge } from '@kiteline/kiteframe';
import '@kiteline/kiteframe/styles';

function EdgeReconnectionDemo() {
  const [nodes, setNodes] = useState<Node[]>([
    { id: '1', type: 'default', position: { x: 100, y: 100 }, 
      data: { label: 'Database' } },
    { id: '2', type: 'default', position: { x: 300, y: 100 }, 
      data: { label: 'API Server' } },
    { id: '3', type: 'default', position: { x: 500, y: 100 }, 
      data: { label: 'Frontend' } },
    { id: '4', type: 'default', position: { x: 300, y: 250 }, 
      data: { label: 'Cache' } }
  ]);

  const [edges, setEdges] = useState<Edge[]>([
    { id: 'e1', source: '1', target: '2', type: 'default' },
    { id: 'e2', source: '2', target: '3', type: 'default' }
  ]);

  const [selectedEdge, setSelectedEdge] = useState<Edge | null>(null);

  const handleEdgeReconnect = (
    edgeId: string, 
    newSource?: string, 
    newTarget?: string
  ) => {
    setEdges(edges => edges.map(edge => 
      edge.id === edgeId 
        ? { ...edge, source: newSource || edge.source, target: newTarget || edge.target }
        : edge
    ));
  };

  return (
    <KiteFrameCanvas
      nodes={nodes}
      edges={edges}
      selectedEdge={selectedEdge}
      onNodesChange={setNodes}
      onEdgesChange={setEdges}
      onEdgeClick={setSelectedEdge}
      onEdgeReconnect={handleEdgeReconnect}
      onClick={() => setSelectedEdge(null)}
    />
  );
}
```

### Advanced Implementation with Validation

```tsx
const handleEdgeReconnect = (
  edgeId: string, 
  newSource?: string, 
  newTarget?: string
) => {
  // Validation: Check if connection already exists
  const connectionExists = edges.some(edge => 
    edge.id !== edgeId && (
      (edge.source === newSource && edge.target === newTarget) ||
      (edge.source === newTarget && edge.target === newSource)
    )
  );

  if (connectionExists) {
    console.warn('Connection already exists between these nodes');
    // Optionally show user notification
    return;
  }

  // Validation: Prevent self-connections
  if (newSource === newTarget) {
    console.warn('Cannot connect node to itself');
    return;
  }

  // Update the edge
  setEdges(prevEdges => {
    const updatedEdges = prevEdges.map(edge => {
      if (edge.id === edgeId) {
        // Log the change for audit trail
        console.log('Edge reconnection:', {
          edgeId,
          from: { source: edge.source, target: edge.target },
          to: { source: newSource || edge.source, target: newTarget || edge.target },
          timestamp: new Date().toISOString()
        });

        return {
          ...edge,
          source: newSource || edge.source,
          target: newTarget || edge.target,
          data: {
            ...edge.data,
            lastModified: new Date().toISOString()
          }
        };
      }
      return edge;
    });

    // Optional: Trigger save to backend
    saveWorkflowToBackend(nodes, updatedEdges);
    
    return updatedEdges;
  });

  // Deselect the edge after successful reconnection
  setSelectedEdge(null);
};
```

## Visual Feedback System

### Handle Appearance
The EdgeHandles component provides visual feedback through:

```typescript
// Handle styles when edge is selected
const handleStyles = {
  idle: {
    fill: '#3b82f6',      // Blue fill
    stroke: 'white',      // White border
    strokeWidth: 3,       // 3px border
    radius: 8,            // 8px radius
    opacity: 1            // Full opacity
  },
  dragging: {
    opacity: 0.7          // Reduced opacity during drag
  }
};
```

### Preview Line During Drag
```typescript
// Dashed preview line shows potential connection
const previewLineStyles = {
  stroke: '#3b82f6',      // Blue color
  strokeWidth: 3,         // 3px width
  strokeDasharray: '5,5', // Dashed pattern
  opacity: 0.8            // Slightly transparent
};
```

### Target Node Highlighting
```typescript
// Blue outline on valid target nodes
const targetHighlight = {
  stroke: '#3b82f6',      // Blue border
  strokeWidth: 3,         // 3px width
  opacity: 0.7,           // Semi-transparent
  borderRadius: 8         // Rounded corners
};
```

## Event Handling

### Preventing Canvas Pan During Drag

The EdgeHandles component automatically prevents canvas panning during edge reconnection:

```tsx
// Internal implementation in EdgeHandles
const handleMouseDown = (event: React.MouseEvent) => {
  event.stopPropagation(); // Prevent event bubbling
  event.preventDefault();   // Prevent default behavior
  
  // Dispatch custom event to notify canvas
  window.dispatchEvent(new CustomEvent('edgeHandleDragStart'));
};

const handleMouseUp = () => {
  // Cleanup and notify canvas that drag is complete
  window.dispatchEvent(new CustomEvent('edgeHandleDragEnd'));
};
```

### Listening for Reconnection Events

```tsx
// Optional: Listen for edge reconnection events
useEffect(() => {
  const handleEdgeReconnected = (event: CustomEvent) => {
    console.log('Edge reconnected:', event.detail);
    // Update UI or trigger side effects
  };

  window.addEventListener('edgeReconnected', handleEdgeReconnected);
  return () => {
    window.removeEventListener('edgeReconnected', handleEdgeReconnected);
  };
}, []);
```

## Customization Options

### Custom Handle Styles

```tsx
// Override default handle styles via CSS
.edge-handle {
  fill: var(--primary-color);
  stroke: var(--background-color);
  stroke-width: 2px;
  cursor: grab;
}

.edge-handle:active {
  cursor: grabbing;
  opacity: 0.8;
}

.edge-handle-preview {
  stroke: var(--primary-color);
  stroke-dasharray: 8, 4;
  animation: dash 0.5s linear infinite;
}

@keyframes dash {
  to {
    stroke-dashoffset: -12;
  }
}
```

### Custom Validation Rules

```tsx
const customValidation = {
  // Maximum connections per node
  maxConnectionsPerNode: 5,
  
  // Allowed connection types
  allowedConnections: {
    'input': ['process'],
    'process': ['process', 'output'],
    'output': []
  },
  
  // Custom validation function
  validateConnection: (source: Node, target: Node) => {
    // Implement custom business logic
    if (source.type === 'input' && target.type === 'output') {
      return false; // Direct input to output not allowed
    }
    return true;
  }
};
```

## Troubleshooting

### Common Issues and Solutions

#### Issue: Handles Not Appearing
**Solution:** Ensure edge is properly selected
```tsx
// Check if selectedEdge is being set correctly
onEdgeClick={(edge) => {
  console.log('Edge clicked:', edge);
  setSelectedEdge(edge);
}}
```

#### Issue: Cannot Drag Handles
**Solution:** Check viewport and coordinate transformations
```tsx
// Ensure viewport is being passed correctly
const viewport = useKiteFrameStore(state => state.viewport);

<EdgeHandles
  edge={selectedEdge}
  viewport={viewport}
  // ... other props
/>
```

#### Issue: Connections Not Updating
**Solution:** Verify state update logic
```tsx
// Add logging to debug state updates
const handleEdgeReconnect = (edgeId, newSource, newTarget) => {
  console.log('Before update:', edges);
  
  setEdges(prev => {
    const updated = prev.map(edge => 
      edge.id === edgeId 
        ? { ...edge, source: newSource || edge.source, target: newTarget || edge.target }
        : edge
    );
    
    console.log('After update:', updated);
    return updated;
  });
};
```

#### Issue: Duplicate Connections Created
**Solution:** Implement duplicate prevention
```tsx
// Check for existing connections before update
const isDuplicate = edges.some(e => 
  e.id !== edgeId && 
  e.source === newSource && 
  e.target === newTarget
);

if (isDuplicate) {
  console.warn('Duplicate connection prevented');
  return;
}
```

## Best Practices

1. **Always provide visual feedback** - Users should see handles when edge is selected
2. **Implement validation** - Prevent invalid connections based on your business logic
3. **Log reconnections** - Maintain audit trail for debugging and analytics
4. **Handle edge cases** - Self-connections, duplicate edges, circular dependencies
5. **Test with zoom/pan** - Ensure feature works at all viewport states
6. **Provide undo/redo** - Allow users to revert accidental reconnections
7. **Save state changes** - Persist reconnections to backend/storage

## API Reference

### EdgeHandles Props

```typescript
interface EdgeHandlesProps {
  edge: Edge;                    // The edge to show handles for
  sourceNode?: Node;             // Source node data
  targetNode?: Node;             // Target node data
  nodes: Node[];                 // All nodes in canvas
  edges: Edge[];                 // All edges in canvas
  onEdgeReconnect?: (            // Callback when reconnection occurs
    edgeId: string, 
    newSource?: string, 
    newTarget?: string
  ) => void;
  viewport?: {                   // Current viewport state
    x: number; 
    y: number; 
    zoom: number;
  };
}
```

## Summary

The Edge Reconnection feature provides a powerful way for users to dynamically modify workflow connections. By following this guide, you can implement:

- ✅ Visual edge handles on selection
- ✅ Drag-to-reconnect behavior
- ✅ Smart validation and feedback
- ✅ Coordinate transformation for zoom/pan
- ✅ Custom styling and validation rules

For additional support or advanced use cases, refer to the main KiteFrame documentation or submit an issue on GitHub.